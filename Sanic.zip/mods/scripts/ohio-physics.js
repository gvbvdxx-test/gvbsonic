var music = null;

gvbsonic.addEventListener("playlevelmusic", function (mus) {
	music = mus;
});

gvbsonic.addEventListener("enginetick", function (plr) {
	var amount = Math.abs(plr.speed)/plr.speedcap;
	
	plr.filter = 'contrast('+((amount*5)+1)+')';
	
	for (var spr of sprites) {
		spr.filter = 'contrast('+((amount*5)+1)+')';
	}
	
	var speed = amount*3;
	if (speed < 0.5) {
		speed = 0.5;
	}
	if (speed > 1) {
		speed = 1;
	}
	
	if (music && music.source) {
		music.source.detune.value = (speed*2000)-2000;
	}
});