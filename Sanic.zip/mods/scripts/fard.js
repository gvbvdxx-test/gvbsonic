//Load funni fard sound.
gvbsonic.addEventListener("afterloaded", async function (files) {
	files.sfx.ring = await loadAudioFile("/audio/fard.wav");
});