class AmogusSussyClass {
    constructor(spr, utils) {
        this.sprite = spr;

        spr.width = 55;
        spr.height = 49;

        this.moreUtils = utils;

        this.amogus1 = true;
        this.amogus2 = 0;
    }
    tileUpdate(spr, util) {
        var gameUtil = util.gameUtil;

        var sonic = gameUtil.sonic;

        var collisionCheck = gameUtil.collisionCheck;

        var Sound = gameUtil.Sound;

        if (this.amogus1) {
            spr.sx += 1;
            spr.flipX = false;
        } else {
            spr.sx -= 1;
            spr.flipX = true;
        }

        this.amogus2 += 1;
        if (this.amogus2 > 100) {
            this.amogus2 = 0;
            this.amogus1 = !this.amogus1;
        }

        if (!sonic.inDebug) {
            if (collisionCheck(sonic, spr) && gameUtil.canGetHurt(sonic)) {
                gameUtil.damageCharacter(sonic);
            }
        }

        var tails = gameUtil.tails;

        if (tails) {
            if (collisionCheck(tails, spr) && gameUtil.canGetHurt(tails)) {
                gameUtil.damageCharacter(tails);
            }
        }
    }
}

gvbsonic.tileBehavior.addTilePrivateClass("amogus", AmogusSussyClass);

class AmogusYellowSussyClass {
    constructor(spr, utils) {
        this.sprite = spr;

        spr.width = 41;
        spr.height = 48;
		
		this.frameCount = 0;
    }
    tileUpdate(spr, util) {
		this.frameCount += 1;
		
		spr.width = 41*Math.cos(this.frameCount/35);
		spr.height = 41*Math.sin(this.frameCount/38);
    }
}

gvbsonic.tileBehavior.addTilePrivateClass("amogus-yellow", AmogusYellowSussyClass);


//Load funni fard sound.
gvbsonic.addEventListener("afterloaded", async function (files) {
	files.sfx.fard = await loadAudioFile("/audio/fard.wav");
});