gvbsonic.addEventListener("afterloaded", async function (files) {
	
	var image = await loadImage("characters/joke.png");
	
	var spritesheet = await gvbsonic.importJSON("characters/joke.json");
	
	var animations = await gvbsonic.importJSON("characters/joke-anim.json");
	
	gvbsonic.addCharacter("s3sonicJoke", {
			name:"Sanic",
			fullname:"Sanic",
			scale:1,
			angle:2,
			smoothAngles:true,
			image:image,
			spritesheet:spritesheet.sprites,
			animations:animations,
			signpostid:"sonic",
			hudicon: await window.loadImage("res/hud/icons/sonic.png"),
			abilites: [
				"spindash",
				"peelout",
				"roll",
				"flight"
			]
	});
	
	gvbsonic.setPlayerCharacter("s3sonicJoke");
	
	gvbsonic.setSpawnCPU(false); //OH MY GOD TAILS, STOP BEING SO ANOYING.
});