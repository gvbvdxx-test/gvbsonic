gvbsonic.addEventListener("tileupdate",function (spr) {
	if ((spr.stype == "tile")) {
		if (!spr.framecountthing) {
			spr.framecountthing = 0;
		}
		spr.framecountthing += 1;
		if (spr.framecountthing > 50) {
			spr.otherthing = !spr.otherthing;
			if (spr.otherthing) {
				spr.direction = 91;
			} else {
				spr.direction = 89;
			}
			spr.framecountthing = 0;
		}
		spr.direction += (90 - spr.direction) / 20;
	}
	
	if ((spr.stype == "ring")) {
		if (!spr.framecountthing) {
			spr.framecountthing = 0;
		}
		spr.framecountthing += 1;
		if (spr.framecountthing > 50) {
			spr.otherthing = !spr.otherthing;
			if (spr.otherthing) {
				spr.direction = 100;
			} else {
				spr.direction = 80;
			}
			spr.framecountthing = 0;
		}
		spr.direction += (90 - spr.direction) / 20;
	}
});