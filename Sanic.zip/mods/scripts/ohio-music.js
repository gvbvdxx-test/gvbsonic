//Fix some audio issues with loud music.

function SANICMUSIC (audio,audioID) {
	if (audioID == "sanic") {
		audio.setVolume(1);
	}
}

gvbsonic.addEventListener("playlevelmusic", SANICMUSIC);