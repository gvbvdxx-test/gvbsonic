gvbsonic.addEventListener("afterloaded", () => {
	gvbsonic.cleanCharacterList();
	gvbsonic.addCharacterToList("s3sonicJoke");
})